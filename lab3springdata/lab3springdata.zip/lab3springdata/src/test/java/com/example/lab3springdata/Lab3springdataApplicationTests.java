package com.example.lab3springdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3springdataApplicationTests {

    @Test
    void contextLoads() {
    }

}
