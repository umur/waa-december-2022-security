package com.example.lab3springdata.aspects.annotation;


public @interface ExecutionTime {
}
